import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: const MyHomePage(title: ''),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: const EdgeInsets.all(20),
        color: Colors.blue.shade900,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
              child: SizedBox(
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: Colors.white,
                  ),
                  child: Column(
                    children: [
                      Expanded(
                        child: SizedBox(
                          child: Container(
                            color: Colors.amber,
                          ),
                        ),
                      ),
                      Expanded(
                        child: SizedBox(
                          child: Container(
                            color: Colors.pink,
                          ),
                        ),
                      ),
                      Expanded(
                        child: SizedBox(
                          child: Container(
                            color: Colors.black,
                          ),
                        ),
                      ),
                      Expanded(
                        child: SizedBox(
                          child: Container(
                            color: Colors.red,
                          ),
                        ),
                      ),
                      Expanded(
                        child: SizedBox(
                          child: Container(
                            color: Colors.purple,
                          ),
                        ),
                      ),
                      Expanded(
                        child: SizedBox(
                          child: Container(
                            color: Colors.grey,
                          ),
                        ),
                      ),
                      Expanded(
                        child: SizedBox(
                          child: Container(
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
