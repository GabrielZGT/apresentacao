import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Visit Cart',
      theme: ThemeData(primarySwatch: Colors.blueGrey),
      home: const MyHomePage(title: 'Visit Cart'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue.shade900,
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: Colors.white,
          ),
          child: Column(
            children: <Widget>[
              Container(
                height: 20,
                child: Container(
                  child: Text(
                    'Cartão Digital',
                    style: TextStyle(
                      color: Colors.blue,
                      fontSize: 20,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 80),
              Container(
                child: CircleAvatar(
                  maxRadius: 80,
                  minRadius: 80,
                  child: Image.asset(
                    "assets/images/eudnv.png",
                    fit: BoxFit.cover,
                    width: 90.0,
                    height: 90.0,
                  ),
                ),
              ),
              SizedBox(height: 50),
              Container(
                child: Column(
                  children: [
                    Text(
                      'Gabriel Filipe',
                      style: TextStyle(
                        fontSize: 32,
                      ),
                    ),
                    Text(
                      'Tester',
                      style: TextStyle(fontSize: 20),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 70),
              Container(
                child: FlatButton(
                  child: Container(
                    height: 50,
                    width: 330,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(25),
                      color: Colors.green.shade500,
                    ),
                    child: Text('WhatsApp',
                        style: TextStyle(
                            color: Color.fromARGB(255, 255, 255, 255),
                            fontFamily: 'Roboto'),
                        textAlign: TextAlign.center),
                  ),
                  onPressed: () {},
                ),
              ),
              SizedBox(height: 40),
              Container(
                height: 80,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      width: 20,
                    ),
                    Expanded(
                      child: SizedBox(
                        child: IconButton(
                            alignment: Alignment.bottomCenter,
                            icon: FaIcon(
                              FontAwesomeIcons.squarePhone,
                              size: 40,
                            ),
                            onPressed: () {}),
                      ),
                    ),
                    Expanded(
                      child: SizedBox(
                        child: IconButton(
                            alignment: Alignment.bottomCenter,
                            icon: FaIcon(
                              FontAwesomeIcons.solidEnvelope,
                              size: 40,
                            ),
                            onPressed: () {}),
                      ),
                    ),
                    Expanded(
                      child: SizedBox(
                        child: IconButton(
                            alignment: Alignment.bottomCenter,
                            icon: FaIcon(
                              FontAwesomeIcons.instagramSquare,
                              size: 40,
                            ),
                            onPressed: () {}),
                      ),
                    ),
                    Expanded(
                      child: SizedBox(
                        child: IconButton(
                            alignment: Alignment.bottomCenter,
                            icon: FaIcon(
                              FontAwesomeIcons.facebookSquare,
                              size: 40,
                            ),
                            onPressed: () {}),
                      ),
                    ),
                    SizedBox(
                      width: 25,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
